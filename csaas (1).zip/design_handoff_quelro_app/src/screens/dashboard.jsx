/* global React, Icon, Stat, Sparkline, Bars, Avatar, Badge, ChannelChip, PageHead */
const DashboardScreen = () => {
  const needs = [
    { n: 'Jay Patel',  ch: '@MarketMavenJay · 142k subs', t: '“Sure, send me details — Friday at 3?”', tag: 'positive', tone: 'coral', hot: true },
    { n: 'Maria Chen', ch: '@ChenFinance · 88k subs',      t: '“What\'s the deliverable and pricing?”', tag: 'question', tone: 'warn', hot: false },
    { n: 'Devon Reed', ch: '@ReedReviewsTech · 312k subs', t: '“Not interested at this time.”',         tag: 'opt-out',  tone: 'bad',  hot: false },
  ];

  const schedule = [
    { h: '09:00', label: 'Mailbox warmup', meta: '4 mailboxes',   status: 'done' },
    { h: '10:30', label: 'Send batch #1',  meta: '412 emails',    status: 'done' },
    { h: '12:00', label: 'Research run',   meta: '184 prospects', status: 'running' },
    { h: '14:00', label: 'Send batch #2',  meta: '360 emails',    status: 'queued' },
    { h: '17:30', label: 'Followup sweep', meta: '220 emails',    status: 'queued' },
    { h: '20:00', label: 'Reply digest',   meta: 'summary',       status: 'queued' },
  ];

  const activity = [
    { t: '2m',  tag: 'scraping',     text: 'Discovered 184 new prospects in Finance YouTube channels (50k–500k subs).', human: false },
    { t: '12m', tag: 'research',     text: 'Studied 42 channels — extracted recent uploads, sponsors, hooks, posting cadence.', human: false },
    { t: '34m', tag: 'writing',      text: 'Drafted 28 personalized opening lines using the “Channel-Hook” template.', human: false },
    { t: '1h',  tag: 'sending',      text: 'Sent 116 emails across 4 mailboxes. 0 bounces, 2 soft fails handled.', human: false },
    { t: '2h',  tag: 'human needed', text: 'Positive reply from @MarketMavenJay — handed off to your inbox.', human: true },
  ];

  const campaigns = [
    { name: 'Finance YT 50k+ · Q2 launch',   niche: 'Finance', color: 'var(--lime)',   sent: 1240, open: '62%', reply: '17%', meet: 12, status: 'live' },
    { name: 'Fitness coaches · sponsorship',  niche: 'Fitness', color: 'var(--rose)',   sent: 820,  open: '54%', reply: '11%', meet: 7,  status: 'live' },
    { name: 'Tech reviewers · 100k+ tier',    niche: 'Tech',    color: 'var(--sky)',    sent: 612,  open: '58%', reply: '14%', meet: 9,  status: 'live' },
    { name: 'Cooking creators · season 2',    niche: 'Cooking', color: 'var(--violet)', sent: 320,  open: '51%', reply: '9%',  meet: 4,  status: 'paused' },
    { name: 'Gaming streamers · brand deals', niche: 'Gaming',  color: 'var(--sky)',    sent: 192,  open: '47%', reply: '8%',  meet: 6,  status: 'live' },
  ];

  const mailboxes = [
    { n: 'sahil@reachagency.io',   warm: 96, sent: 142, max: 180 },
    { n: 'team@reachagency.io',     warm: 89, sent: 96,  max: 150 },
    { n: 'hello@reachfounder.co',   warm: 92, sent: 124, max: 180 },
    { n: 'pitch@rocketreach.email', warm: 78, sent: 50,  max: 100 },
  ];

  return (
    <div className="page dash">
      {/* ---- Overnight brief ---- */}
      <header className="brief">
        <div className="brief__top">
          <span className="kicker"><i/>Wed · May 27 · 06:42 — overnight report</span>
          <div className="row" style={{gap: 10}}>
            <button className="btn btn--ghost"><Icon name="plus" />Import leads</button>
            <button className="btn btn--primary"><Icon name="rocket" size={14}/>New campaign</button>
          </div>
        </div>
        <h1 className="brief__lede">
          While you slept, the agents sent <em>412 emails</em> and booked <em>2 meetings</em>. <b>3 replies</b> need you.
        </h1>
      </header>

      {/* ---- Stat band ---- */}
      <div className="statband">
        <div className="cell"><div className="cl">Emails sent · 7d</div><div className="cv">3,184</div><div className="cd up"><Icon name="arrowUp" size={11}/>+18.4%</div></div>
        <div className="cell"><div className="cl">Reply rate</div><div className="cv">14.2%</div><div className="cd up"><Icon name="arrowUp" size={11}/>+2.1 pts</div></div>
        <div className="cell"><div className="cl">Meetings booked</div><div className="cv">38</div><div className="cd up"><Icon name="arrowUp" size={11}/>+9 this month</div></div>
        <div className="cell"><div className="cl">Deliverability</div><div className="cv">98.6%</div><div className="cd">Healthy</div></div>
      </div>

      {/* ---- Priority: needs a human + today's plan ---- */}
      <div className="dsec">
        <span className="kicker clay"><i/>Needs a human · <b>3</b></span>
        <a className="dsec__act">Open inbox <Icon name="arrowR" size={12}/></a>
      </div>
      <div className="grid" style={{gridTemplateColumns: '1.55fr 1fr', gap: 20, alignItems: 'start'}}>
        <div className="needs">
          {needs.map((r, i) => (
            <div key={i} className={`needs__row ${r.hot ? 'hot' : ''}`}>
              <Avatar name={r.n} />
              <div className="needs__main">
                <div className="row" style={{justifyContent: 'space-between', gap: 10}}>
                  <span className="needs__name">{r.n}</span>
                  <Badge kind={r.tone}>{r.tag}</Badge>
                </div>
                <div className="needs__ch">{r.ch}</div>
                <div className="needs__msg">{r.t}</div>
              </div>
              {r.hot
                ? <button className="btn btn--primary btn--sm" style={{alignSelf: 'center'}}>Reply <Icon name="arrowR" size={11}/></button>
                : <button className="btn btn--ghost btn--sm" style={{alignSelf: 'center'}}>Open</button>}
            </div>
          ))}
        </div>

        <div className="card">
          <div className="card__head">
            <div className="card__title">Today's plan</div>
            <button className="btn btn--ghost btn--sm">Pause</button>
          </div>
          <div className="card__body" style={{padding: 0}}>
            {schedule.map((row, i) => (
              <div key={i} style={{display:'flex', alignItems:'center', gap: 12, padding: '12px 16px', borderBottom: i < schedule.length - 1 ? '1px solid var(--line)' : 'none'}}>
                <div className="mono" style={{color:'var(--text-3)', fontSize: 11, width: 42}}>{row.h}</div>
                <div style={{flex: 1}}>
                  <div style={{fontSize: 12.5}}>{row.label}</div>
                  <div className="mono muted" style={{fontSize: 10.5, marginTop: 1}}>{row.meta}</div>
                </div>
                {row.status === 'done' && <Badge kind="ghost"><Icon name="check" size={11}/>Done</Badge>}
                {row.status === 'running' && <Badge kind="lime"><span className="dot dot--pulse"/>Now</Badge>}
                {row.status === 'queued' && <span className="muted mono" style={{fontSize: 11}}>Queued</span>}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ---- Agent activity ledger ---- */}
      <div className="dsec">
        <span className="kicker"><i/>Agent activity · live</span>
        <a className="dsec__act">Last 24h · view all</a>
      </div>
      <div className="ledger">
        {activity.map((row, i) => (
          <div key={i} className="ledger__row">
            <span className="ledger__t">{row.t} ago</span>
            <span className={`ledger__tag ${row.human ? 'clay' : ''}`}>{row.tag}</span>
            <span className="ledger__txt">{row.text}</span>
            {row.human && <button className="btn btn--ghost btn--sm" style={{alignSelf: 'center'}}>Reply <Icon name="arrowR" size={11}/></button>}
          </div>
        ))}
      </div>

      {/* ---- Active campaigns ---- */}
      <div className="dsec">
        <span className="kicker">Active campaigns · 5</span>
        <a className="dsec__act">View all <Icon name="chev" size={11}/></a>
      </div>
      <div className="card" style={{overflow: 'hidden'}}>
        <table className="tbl">
          <thead>
            <tr>
              <th style={{width: '38%'}}>Campaign</th>
              <th>Niche</th>
              <th className="num">Sent</th>
              <th className="num">Open</th>
              <th className="num">Reply</th>
              <th className="num">Meetings</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {campaigns.map((c, i) => (
              <tr key={i}>
                <td><div style={{fontWeight: 500}}>{c.name}</div></td>
                <td><ChannelChip color={c.color}>{c.niche}</ChannelChip></td>
                <td className="num">{c.sent.toLocaleString()}</td>
                <td className="num">{c.open}</td>
                <td className="num" style={{color: 'var(--coral)'}}>{c.reply}</td>
                <td className="num">{c.meet}</td>
                <td>
                  {c.status === 'live'
                    ? <Badge kind="lime"><span className="dot dot--pulse"/>Live</Badge>
                    : <Badge kind="warn">Paused</Badge>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ---- Mailbox health ---- */}
      <div className="dsec">
        <span className="kicker">Mailbox health</span>
        <Badge kind="ok"><Icon name="check" size={11}/>All systems</Badge>
      </div>
      <div className="grid g-4">
        {mailboxes.map((m, i) => (
          <div key={i} className="card" style={{padding: 16}}>
            <div className="mono" style={{fontSize: 11.5, marginBottom: 12, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap'}}>{m.n}</div>
            <div className="row" style={{justifyContent: 'space-between', marginBottom: 6}}>
              <span className="muted" style={{fontSize: 10.5, letterSpacing: '.06em'}}>WARM</span>
              <span className="mono" style={{fontSize: 11}}>{m.warm}%</span>
            </div>
            <div className="bar" style={{marginBottom: 12}}><span style={{width: `${m.warm}%`}}/></div>
            <div className="row" style={{justifyContent: 'space-between'}}>
              <span className="muted" style={{fontSize: 10.5, letterSpacing: '.06em'}}>TODAY</span>
              <span className="mono" style={{fontSize: 11}}>{m.sent} / {m.max}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

window.DashboardScreen = DashboardScreen;
