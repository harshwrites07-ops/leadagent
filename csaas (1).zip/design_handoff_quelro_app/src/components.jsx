/* global React */
const { useState, useEffect, useRef, useMemo } = React;

/* =========================================================
   Icons — tiny inline SVG set (1.5 stroke, 16px)
   ========================================================= */
const Icon = ({ name, size = 16, className = '' }) => {
  const p = {
    width: size, height: size, viewBox: '0 0 24 24',
    fill: 'none', stroke: 'currentColor', strokeWidth: 1.5,
    strokeLinecap: 'round', strokeLinejoin: 'round',
    className: `ic ${className}`,
  };
  const paths = {
    home:      <><path d="M3.5 10.5 12 4l8.5 6.5"/><path d="M5.5 9.5V20h13V9.5"/></>,
    users:     <><circle cx="9" cy="8.5" r="3"/><path d="M3.5 19c.4-2.8 2.7-4.5 5.5-4.5s5.1 1.7 5.5 4.5"/><path d="M16 6.2a2.6 2.6 0 0 1 0 5M18 18.6c-.2-1.7-1-3-2.3-3.8"/></>,
    rocket:    <><path d="M5 15c-1.2.7-2 2-2 4 2 0 3.3-.8 4-2"/><path d="M9 13c1-3.5 3.5-7 8.5-8 .5 4.5-1.5 8-5 9.5z"/><circle cx="14.5" cy="8.5" r="1.3"/></>,
    flow:      <><circle cx="6" cy="6" r="1.8"/><circle cx="18" cy="12" r="1.8"/><circle cx="6" cy="18" r="1.8"/><path d="M7.8 6H12a4 4 0 0 1 4 4M7.8 18H12a4 4 0 0 0 4-4"/></>,
    inbox:     <><path d="M4 4h16v16H4z"/><path d="M4 14h4l1.5 2.5h5L16 14h4"/></>,
    sparkle:   <><path d="M12 3.5c.6 4 2 5.4 6 6-4 .6-5.4 2-6 6-.6-4-2-5.4-6-6 4-.6 5.4-2 6-6z"/></>,
    bar:       <><path d="M4 20V4"/><path d="M4 20h16"/><rect x="7" y="12" width="3" height="5"/><rect x="12" y="8" width="3" height="9"/><rect x="17" y="5" width="3" height="12"/></>,
    flame:     <><path d="M12 3c.5 4 4 4 4 9a4 4 0 1 1-8 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-5 0-8z"/></>,
    plus:      <><path d="M12 5v14M5 12h14"/></>,
    chev:      <><path d="m9 6 6 6-6 6"/></>,
    chevd:     <><path d="m6 9 6 6 6-6"/></>,
    search:    <><circle cx="11" cy="11" r="6.5"/><path d="m20 20-3.5-3.5"/></>,
    bell:      <><path d="M6 9a6 6 0 0 1 12 0c0 5 2 6 2 6H4s2-1 2-6z"/><path d="M10.5 20a1.5 1.5 0 0 0 3 0"/></>,
    help:      <><circle cx="12" cy="12" r="8.5"/><path d="M9.5 9.2a2.5 2.5 0 1 1 3.5 2.3c-.8.4-1 1-1 1.7M12 16.5v.5"/></>,
    filter:    <><path d="M4 6h16l-6 7v5l-4 1.5V13z"/></>,
    sort:      <><path d="M7 4v14M3 14l4 4 4-4M17 20V6M13 10l4-4 4 4"/></>,
    play:      <><path d="m7 5 12 7-12 7z"/></>,
    pause:     <><path d="M7 5h3v14H7zM14 5h3v14h-3z"/></>,
    mail:      <><path d="M3 6h18v12H3z"/><path d="m3 7 9 7 9-7"/></>,
    youtube:   <><rect x="2" y="6" width="20" height="12" rx="3"/><path d="m10 9 5 3-5 3z" fill="currentColor" stroke="none"/></>,
    globe:     <><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/></>,
    star:      <><path d="m12 3 2.6 5.6 6.2.7-4.6 4.2 1.2 6L12 16.7 6.6 19.5l1.2-6L3.2 9.3l6.2-.7z"/></>,
    reply:     <><path d="M9 5 3 11l6 6M3 11h12a6 6 0 0 1 6 6"/></>,
    settings:  <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3h0a1.7 1.7 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8v0a1.7 1.7 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></>,
    cmd:       <><path d="M9 6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3z"/></>,
    arrowUp:   <><path d="M12 19V5M5 12l7-7 7 7"/></>,
    arrowDown: <><path d="M12 5v14M5 12l7 7 7-7"/></>,
    arrowR:    <><path d="M5 12h14M13 5l7 7-7 7"/></>,
    check:     <><path d="m5 12 5 5 9-11"/></>,
    x:         <><path d="m6 6 12 12M6 18 18 6"/></>,
    clock:     <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    target:    <><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/></>,
    bolt:      <><path d="M13 3 4 14h7l-1 7 9-11h-7z"/></>,
    link:      <><path d="M10 13a5 5 0 0 0 7 0l2-2a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-2 2a5 5 0 0 0 7 7l1-1"/></>,
    moreH:     <><circle cx="6" cy="12" r="1.4" fill="currentColor"/><circle cx="12" cy="12" r="1.4" fill="currentColor"/><circle cx="18" cy="12" r="1.4" fill="currentColor"/></>,
    sliders:   <><path d="M4 6h10M18 6h2M4 12h2M10 12h10M4 18h14M18 18h2"/><circle cx="16" cy="6" r="2"/><circle cx="8" cy="12" r="2"/><circle cx="16" cy="18" r="2"/></>,
    eye:       <><path d="M2.5 12s3.5-6.5 9.5-6.5S21.5 12 21.5 12s-3.5 6.5-9.5 6.5S2.5 12 2.5 12z"/><circle cx="12" cy="12" r="2.7"/></>,
    pen:       <><path d="m4 20 4-1 11-11-3-3L5 16z"/><path d="m14 6 3 3"/></>,
    layers:    <><path d="m12 3.5 8.5 4.5-8.5 4.5L3.5 8z"/><path d="m3.5 12 8.5 4.5 8.5-4.5M3.5 16l8.5 4.5 8.5-4.5"/></>,
  };
  return <svg {...p}>{paths[name] || null}</svg>;
};

/* =========================================================
   Sidebar
   ========================================================= */
const NAV = [
  { id: 'dashboard', label: 'Dashboard',       icon: 'home',    tag: 'DASH' },
  { id: 'finder',    label: 'Lead Finder',     icon: 'target',  tag: 'FIND' },
  { id: 'analyzer',  label: 'Channel Analyzer',icon: 'eye',     tag: 'SCAN' },
  { id: 'pitch',     label: 'Pitch Gen',       icon: 'sparkle', tag: 'PTCH' },
  { id: 'sender',    label: 'Email Sender',    icon: 'inbox',   tag: 'MAIL', dot: true },
  { id: 'crm',       label: 'CRM',             icon: 'layers',  tag: 'CRM_' },
  { id: 'analytics', label: 'Analytics',       icon: 'bar',     tag: 'DATA' },
  { id: 'settings',  label: 'Settings',        icon: 'settings',tag: 'CONF' },
];

const Sidebar = ({ route, setRoute, openAgent }) => (
  <aside className="sb">
    <div className="sb__brand">
      <div className="sb__logo"><span>Q</span></div>
      <div>
        <div className="sb__brand-name">Quelro</div>
        <div className="muted" style={{fontSize: 10.5, marginTop: 1, fontFamily: 'var(--f-mono)', letterSpacing: '.08em'}}>OUTREACH·OS</div>
      </div>
    </div>

    <button className="sb__org" onClick={openAgent} style={{textAlign:'left', cursor:'pointer'}}>
      <div className="agent__bot-avatar" style={{width: 24, height: 24, borderRadius: 7}}/>
      <div>
        <div className="sb__org-name">Ask the agent</div>
        <div className="sb__org-role">Type or press <kbd style={{fontFamily:'var(--f-mono)', fontSize: 9.5, background:'var(--bg-2)', border:'1px solid var(--line)', padding:'0 4px', borderRadius: 3}}>⌘K</kbd></div>
      </div>
    </button>

    <div>
      <div className="sb__section">Workspace</div>
      <nav className="sb__nav">
        {NAV.map(item => (
          <NavItem key={item.id} item={item} active={route === item.id} onClick={() => setRoute(item.id)} />
        ))}
      </nav>
    </div>

    <div className="sb__foot">
      <div className="sb__usage">
        <div className="sb__usage-top">
          <span className="sb__usage-label"><Icon name="inbox" size={13}/>Emails</span>
          <span className="sb__usage-meta">247 / 500</span>
        </div>
        <div className="sb__credit-bar"><div className="sb__credit-fill" style={{width: '49%'}} /></div>
        <div className="sb__usage-sub">253 remaining this month</div>
      </div>
      <div className="sb__org" style={{cursor:'pointer'}}>
        <div className="sb__org-ava">RR</div>
        <div>
          <div className="sb__org-name">Rocket Reach</div>
          <div className="sb__org-role">Pro · 4 seats</div>
        </div>
        <Icon name="chevd" size={14} className="sb__org-chev" />
      </div>
    </div>
  </aside>
);

const NavItem = ({ item, active, onClick }) => (
  <button className={`sb__item ${active ? 'is-active' : ''}`} onClick={onClick} data-comment-anchor={`nav-${item.id}`}>
    <Icon name={item.icon} />
    <span>{item.label}</span>
    {item.dot && <span className="sb__item-dot" style={{background: 'var(--coral)', boxShadow: '0 0 0 3px var(--coral-soft)'}} />}
  </button>
);

/* =========================================================
   Topbar
   ========================================================= */
const Topbar = ({ crumbs = [], actions = null }) => (
  <header className="tb">
    <div className="tb__crumbs">
      {crumbs.map((c, i) => (
        <React.Fragment key={i}>
          {i > 0 && <Icon name="chev" size={12} className="tb__sep" />}
          <span className={`tb__crumb ${i === crumbs.length - 1 ? 'is-current' : ''}`}>{c}</span>
        </React.Fragment>
      ))}
    </div>

    <div className="tb__search">
      <Icon name="search" size={13} />
      <span>Search leads, campaigns, replies…</span>
      <kbd>⌘K</kbd>
    </div>

    <div className="tb__right">
      {actions}
      <button className="tb__icon-btn"><Icon name="help" /></button>
      <button className="tb__icon-btn"><Icon name="bell" /></button>
      <div className="tb__avatar">SJ</div>
    </div>
  </header>
);

/* =========================================================
   Reusable primitives
   ========================================================= */
const Stat = ({ label, value, delta, trend, mono = false, spark = null }) => (
  <div className="stat">
    <div className="stat__label">{label}</div>
    <div className={mono ? 'stat__value stat__value--mono' : 'stat__value'}>{value}</div>
    {delta != null && (
      <div className={`stat__delta ${trend === 'up' ? 'stat__delta--up' : trend === 'down' ? 'stat__delta--down' : ''}`}>
        <Icon name={trend === 'up' ? 'arrowUp' : trend === 'down' ? 'arrowDown' : 'arrowR'} size={11} />
        {delta}
      </div>
    )}
    {spark && <div className="stat__spark">{spark}</div>}
  </div>
);

const Bars = ({ data, hiIdx = -1 }) => (
  <div className="bars">
    {data.map((v, i) => (
      <span
        key={i}
        className={i === hiIdx ? 'hi' : ''}
        style={{ height: `${v}%` }}
      />
    ))}
  </div>
);

/* Smooth sparkline using SVG path */
const Sparkline = ({ data, color = 'var(--lime)', height = 36, fill = true }) => {
  const w = 200, h = height;
  const min = Math.min(...data), max = Math.max(...data);
  const span = (max - min) || 1;
  const pts = data.map((v, i) => [
    (i / (data.length - 1)) * w,
    h - ((v - min) / span) * (h - 4) - 2,
  ]);
  const d = pts.map((p, i) => (i === 0 ? `M${p[0]},${p[1]}` : `L${p[0]},${p[1]}`)).join(' ');
  const dFill = `${d} L${w},${h} L0,${h} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" style={{width: '100%', height: h}}>
      {fill && <path d={dFill} fill={color} opacity={0.10} />}
      <path d={d} fill="none" stroke={color} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
};

const Avatar = ({ name, color, size = 'md', img = null }) => {
  const init = (name || '?').split(' ').map(p => p[0]).slice(0, 2).join('').toUpperCase();
  const cls = size === 'sm' ? 'ava ava--sm' : size === 'lg' ? 'ava ava--lg' : size === 'xl' ? 'ava ava--xl' : 'ava';
  const palette = ['#1f3a5f','#1d4d39','#3a2f5f','#5a4520','#5a2530','#214e54','#3a3a3a'];
  const bg = color || palette[(name?.charCodeAt(0) ?? 0) % palette.length];
  return (
    <span className={cls} style={{background: bg}}>
      {img ? <img src={img} alt="" style={{width:'100%', height:'100%', borderRadius:'50%', objectFit:'cover'}}/> : init}
    </span>
  );
};

const Badge = ({ children, kind = '' }) => (
  <span className={`badge ${kind ? 'badge--' + kind : ''}`}>{children}</span>
);

/* Channel icon chip — for YouTube niches etc */
const ChannelChip = ({ children, color = 'var(--rose)' }) => (
  <span className="chan"><span className="chan__dot" style={{background: color}}/>{children}</span>
);

/* Page header standard layout */
const PageHead = ({ title, sub, eyebrow, actions }) => (
  <div className="page__head">
    <div>
      {eyebrow && <div className="muted" style={{fontSize: 11.5, textTransform: 'uppercase', letterSpacing: '.08em', marginBottom: 8}}>{eyebrow}</div>}
      <h1 className="page__title" dangerouslySetInnerHTML={{__html: title}} />
      {sub && <div className="page__sub">{sub}</div>}
    </div>
    {actions && <div className="page__actions">{actions}</div>}
  </div>
);

/* =========================================================
   System bar — bottom strip showing what's running
   ========================================================= */
const SystemBar = ({ openAgent }) => (
  <div className="sysbar">
    <span className="sysbar__svc"><span className="sysbar__dot" style={{background:'var(--text-4)'}}/>Scraper</span>
    <span className="sysbar__svc"><span className="sysbar__dot" style={{background:'var(--text-4)'}}/>YT API</span>
    <span className="sysbar__svc"><span className="sysbar__dot" style={{background:'var(--text-4)'}}/>Gemini</span>
    <span className="sysbar__svc"><span className="sysbar__dot" style={{background:'var(--text-4)'}}/>SMTP</span>
    <span className="sysbar__svc" style={{color:'var(--text-2)'}}><span className="sysbar__dot dot--pulse" style={{background:'var(--lime)'}}/>2 agents working</span>
    <span className="spacer"/>
    <span style={{color:'var(--text-4)'}}>v2.4.1 · uptime 12d 4h</span>
    <span className="sysbar__svc">
      <button onClick={openAgent} style={{display:'inline-flex', alignItems:'center', gap:6, color:'var(--text-3)'}}>
        Ask agent <kbd>⌘K</kbd>
      </button>
    </span>
  </div>
);

/* =========================================================
   Agent — global slide-out
   ========================================================= */
const Agent = ({ open, onClose }) => {
  const [input, setInput] = React.useState('');
  const [thread, setThread] = React.useState([
    { from: 'bot', text: "Morning Sahil. I scraped 184 new Finance creators overnight and ran your Q2 sequence. 3 replied positively — they're waiting in your inbox." },
    { from: 'bot', action: { tag: 'COMPLETED', title: 'Scraped 184 prospects · Finance 50k-500k', running: false }},
    { from: 'bot', action: { tag: 'COMPLETED', title: 'Sent 412 emails across 4 mailboxes', running: false }},
    { from: 'bot', action: { tag: 'RUNNING',   title: 'Drafting 28 follow-ups for opens with no reply', running: true }},
  ]);

  const send = (text) => {
    const t = (text ?? input).trim();
    if (!t) return;
    setThread(prev => [
      ...prev,
      { from: 'user', text: t },
      { from: 'bot', text: "On it. I'll search Finance YouTube channels between 100k–300k subs that don't already sponsor Acorns or Public, draft a pitch for each using your standard brief, and queue them for review." },
      { from: 'bot', action: { tag: 'RUNNING', title: `Searching: ${t.slice(0, 50)}...`, running: true } },
    ]);
    setInput('');
  };

  if (!open) return null;

  return (
    <aside className="agent">
      <div className="agent__head">
        <div className="agent__avatar"/>
        <div>
          <h3>Agent</h3>
          <div className="muted">Online · model gemini-2.5-pro</div>
        </div>
        <button className="agent__close" onClick={onClose}><Icon name="x" size={14}/></button>
      </div>

      <div className="agent__body">
        {thread.map((m, i) => (
          <div key={i} className={`agent__msg agent__msg--${m.from}`}>
            {m.from === 'bot' && <div className="agent__bot-avatar"/>}
            <div className="agent__bubble">
              {m.text && <div>{m.text}</div>}
              {m.action && (
                <div className={`agent__action ${m.action.running ? 'is-running' : ''}`}>
                  <span className="tag">{m.action.tag}</span>
                  <span style={{flex: 1}}>{m.action.title}</span>
                  {m.action.running && <span className="dot dot--pulse" style={{background:'var(--lime)', width:8, height:8}}/>}
                  {!m.action.running && <Icon name="check" size={12} className="" />}
                </div>
              )}
            </div>
          </div>
        ))}

        <div className="agent__chips">
          <button className="agent__chip" onClick={() => send('Find 50 Tech creators 100k-300k subs')}>Find 50 Tech creators 100k-300k</button>
          <button className="agent__chip" onClick={() => send('Write a pitch for @MarketMavenJay')}>Write a pitch for @MarketMavenJay</button>
          <button className="agent__chip" onClick={() => send('Move all hot leads to "Call booked"')}>Move all hot leads to "Call booked"</button>
          <button className="agent__chip" onClick={() => send("Why did my reply rate drop yesterday?")}>Why did my reply rate drop?</button>
        </div>
      </div>

      <div className="agent__composer">
        <div className="agent__composer-inner">
          <textarea
            className="agent__input"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }}}
            placeholder="Ask the agent to find, write, send, or analyze…"
            rows={1}
          />
          <button className="agent__send" disabled={!input.trim()} onClick={() => send()}>
            <Icon name="arrowUp" size={13}/>
          </button>
        </div>
        <div className="agent__hint">
          <span><kbd>↵</kbd> send</span>
          <span><kbd>⇧↵</kbd> new line</span>
          <span><kbd>⌘K</kbd> toggle</span>
        </div>
      </div>
    </aside>
  );
};

/* Export to window */
Object.assign(window, {
  Icon, Sidebar, Topbar, Stat, Bars, Sparkline, Avatar, Badge, ChannelChip, PageHead, NAV,
  SystemBar, Agent,
});
