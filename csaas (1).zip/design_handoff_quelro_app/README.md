# Handoff: Quelro — Full Product (App + Landing)

## Overview
**Quelro** is an autonomous cold-outreach OS for agencies that pitch YouTube creators. It runs a four-stage pipeline — **Find → Pitch → Send → Learn** — through specialized agents, with a human approving the moments that matter. This package covers the **entire product**: the marketing landing page **and** the full in-app experience (8 primary screens + an AI agent panel + an onboarding overlay).

The goal of this handoff is a **complete redesign / reskin of the whole SaaS** into the "Aurora" dark theme described below — not just the landing page.

## About the Design Files
The files in `src/` and `landing/` are **design references created in HTML/CSS/JSX** (React via in-browser Babel — a prototype, not a build). **Do not ship them verbatim.** Recreate the design in the target codebase's real environment (Next/React, Vue, etc.) using its existing component patterns, router, and styling system. If no front-end exists yet, pick an appropriate stack and implement there.

Treat `src/styles.css` (the `:root` token block especially) and the per-screen `.jsx` files as the **authoritative source of truth** for color, spacing, copy, and layout. The PNGs in `reference/` show each finished screen.

## Fidelity
**High-fidelity (hifi).** Final colors, type, spacing, copy, and interactions. Rebuild faithfully; map the tokens below onto the host codebase's design system rather than scattering hex values.

---

## Design Tokens (authoritative — from `src/styles.css :root`)

### Surfaces (dark "Aurora")
| Token | Value | Use |
|---|---|---|
| `--bg` | `#08090C` | App canvas (cool near-black) |
| `--bg-2` | `#060709` | Deepest wells, inset chips |
| `--surface` | `#101218` | Cards, panels |
| `--surface-2` | `#161922` | Raised card / hover surface |
| `--surface-3` | `#1E222C` | Inputs, pills, avatars |
| `--hover` | `#1A1E27` | Row hover |

### Lines (translucent white on near-black)
| `--line` | `rgba(255,255,255,0.075)` | Hairline borders |
| `--line-2` | `rgba(255,255,255,0.13)` | Default borders |
| `--line-3` | `rgba(255,255,255,0.20)` | Strong/active borders |

### Text (cool whites)
| `--text` | `#F2F4F8` | Primary |
| `--text-2` | `#9BA2AE` | Secondary |
| `--text-3` | `#646B78` | Tertiary / mono labels |
| `--text-4` | `#424955` | Faint |

### Accents (semantic — color carries meaning, not decoration)
| Token | Value | Meaning |
|---|---|---|
| `--lime` | `#2FE08C` | **EMERALD** = machine/agent/primary action/active/positive. (Token name is legacy; it is emerald.) |
| `--lime-2` | `#54E8A2` | emerald hover |
| `--lime-dim` | `#1FA968` | emerald pressed/dim |
| `--lime-soft` | `rgba(47,224,140,0.12)` | emerald tint bg |
| `--lime-border` | `rgba(47,224,140,0.34)` | emerald border |
| `--coral` | `#FF8A6B` | **CORAL** = human / reply / needs-attention |
| `--coral-soft` | `rgba(255,138,107,0.12)` | coral tint bg |
| `--coral-border` | `rgba(255,138,107,0.34)` | coral border |
| `--sky` | `#6E8BFF` | links / info |
| `--violet` | `#A98BFF` | secondary category |
| `--ok` / `--warn` / `--bad` | `#2FE08C` / `#F5C451` / `#FF6B6B` | status |
| on-accent text | `#06170F` | near-black text ON emerald/coral fills — **never white on emerald** |

### Type
- `--f-display`: **Bricolage Grotesque** (400–800) — big headings, hero numbers, stat values. Tight tracking (−0.03 to −0.045em).
- `--f-sans`: **Geist** (300–700) — all UI/body.
- `--f-mono`: **Geist Mono** (400–500) — eyebrows/kickers, data values, table numerals, tags, IDs. Often uppercase, `letter-spacing: .08–.1em`.
- Min UI text 11px (mono labels); body 13–15px; section titles 28px; hero number 88px.

### Radius / depth
- Radius: sm 8 · base 11 · md 14 · lg 18 · xl 24 (px).
- Shadows: `--shadow-sm` `0 1px 2px rgba(0,0,0,.5)`; `--shadow` `0 16px 40px -20px rgba(0,0,0,.62)`; `--shadow-lg` `0 34px 70px -28px rgba(0,0,0,.72)`; top lit edge `--lit` `inset 0 1px 0 rgba(255,255,255,0.05)`.
- Emerald glow (primary CTA hover): `--glow-iris` `0 12px 30px -10px rgba(47,224,140,.40)`.

### Atmosphere
Body has **fixed radial-gradient aurora glows** over `--bg`: emerald `rgba(47,224,140,0.10)` top-left, indigo `rgba(110,139,255,0.07)` top-right, emerald `rgba(47,224,140,0.05)` bottom-right. Plus a ~4% film-grain SVG noise overlay at `mix-blend-mode: soft-light`. The app shell (`.app`, `.main`) is transparent so the glow shows through.

### Layout
Sidebar width `244px`; topbar height `58px`. App is a CSS grid: `grid-template-columns: var(--sidebar-w) 1fr`.

---

## App Shell (`src/app.jsx`, `src/components.jsx`)

**Three-region layout:** left **Sidebar** + main column (**Topbar** over scrolling screen) + a right-docked **Agent** drawer. A bottom **SystemBar** sits above content.

### Sidebar (`.sb`)
- **Brand block**: emerald rounded `.sb__logo` square with "Q" (near-black glyph) + "Quelro" / mono "OUTREACH·OS".
- **"Ask the agent"** button (opens Agent drawer; shows `⌘K` hint).
- **Workspace nav** — 8 items, each an icon + label + 4-char mono tag; the Email Sender item shows a status dot:
  1. Dashboard (home / DASH) · 2. Lead Finder (target / FIND) · 3. Channel Analyzer (eye / SCAN) · 4. Pitch Gen (sparkle / PTCH) · 5. Email Sender (inbox / MAIL, dot) · 6. CRM (layers / CRM_) · 7. Analytics (bar / DATA) · 8. Settings (settings / CONF).
  - Active item: `--surface-2` fill, `--line-3` border, emerald icon/accent.
- **Foot**: **email-usage meter** — "Emails · 247 / 500" with a thin progress bar (49%) + "253 remaining this month" (this replaced an older "AI credits" meter — keep the email-usage version). Then an org row: "RR" avatar, "Rocket Reach", "Pro · 4 seats", chevron.

### Topbar (`.tb`)
- Background `rgba(8,9,12,0.72)` + `backdrop-filter: blur(16px) saturate(140%)`, hairline bottom.
- Left: breadcrumbs per route (see routes). Right: "Onboarding" ghost button + "Agent ⌘K" button.

### Routes (`ROUTES` in app.jsx)
`dashboard` (Dashboard) · `finder` (Outreach › Lead Finder) · `analyzer` (Outreach › Channel Analyzer › @MarketMavenJay) · `pitch` (Outreach › Pitch Gen) · `sender` (Outreach › Email Sender) · `crm` (CRM, full-bleed) · `analytics` (Analytics) · `settings` (Settings). Each tagged with a `data-screen-label` like "01 Dashboard".

### Agent drawer (`Agent`)
Right-docked panel toggled by **⌘K / Ctrl+K** or any "Agent"/"Ask the agent" button. When open, `.app` gets `.agent-open`. Emerald bot avatar, chat thread, message input with emerald send button. Treat as a slide-in drawer (~360–420px) with overlay/inline push.

### SystemBar
Thin status strip above content (system/agent state); opens the agent.

### Onboarding overlay (`src/screens/onboarding.jsx`)
Full-screen modal launched from the Topbar "Onboarding" button. Stepped flow with a numbered step rail (done = emerald check, current = highlighted), Quelro logo. Dismissible.

---

## Screens (`src/screens/*.jsx` — see `reference/*.png`)

> All screens share the editorial system: a **mono kicker/eyebrow**, a **display title** (Bricolage) sometimes with an emerald `em` clause, hairline-divided sections, mono numerals, and cards on `--surface`. Color is semantic: emerald = agent/positive/action, coral = human/reply/attention.

### 01 · Dashboard (`dashboard.jsx`)
Editorial "overnight brief" — **no greeting-with-emoji trope**. Top: kicker (date) + a sentence-style headline summarizing overnight agent activity, with "**N conversations need a human**" promoted and colored coral. A **hairline-divided stat band** (not floating cards) with mono values + deltas. A **"Needs a human"** lane of reply cards (coral signal). A ledger-style **activity feed**. CTAs route to CRM / Sender / open Agent.

### 02 · Lead Finder (`finder.jsx`)
PowerMode lead search. Niche chips (each with a count), a query/criteria area, and a results list of scored creator rows (avatar, name, subs/niche, emerald **fit-score** badge). Has a lead-count input + live "scanning" state. Routes to Analyzer.

### 03 · Channel Analyzer (`analyzer.jsx`)
Per-channel **dossier**: round channel monogram, headline KPIs (avg views, sponsor slots), an audience-overlap bar vs ICP, best-fit + estimated-CPM tags, and a suggested angle. Routes to Pitch.

### 04 · Pitch Gen (`pitch.jsx`)
AI draft composer: a `pitch_gen` card with a personalized draft email (TO line + body referencing the creator's real content), "personalized" + "approve & send" tags, and A/B variant affordances. Routes to Sender.

### 05 · Email Sender (`sender.jsx`)
Multi-mailbox sending console: mailbox rows with per-mailbox throttle/progress bars, deliverability stat ("98.6% delivered"), "warmup active" tag, follow-up cadence. Status dot in nav reflects live sending.

### 06 · CRM (`crm.jsx`, full-bleed)
Pipeline board (kanban) of deals/conversations across stages; monochrome cards with mono values; reply items flagged coral. Full-bleed layout (no side padding).

### 07 · Analytics (`analytics.jsx`)
Metrics dashboard: big Bricolage hero number(s), trend charts/bars, reply-rate and meetings-booked series. Positive deltas emerald; human metrics (meetings) can use coral/emerald per semantics.

### 08 · Settings (`settings.jsx`)
Workspace/account settings: sectioned forms, toggles, mailbox connections, team seats, plan (Pro). Standard form controls in the dark theme.

---

## Interactions & Behavior
- **⌘K / Ctrl+K** toggles the Agent drawer (global keydown).
- **Nav**: clicking a sidebar item swaps the screen (client routing); active item styled as above; breadcrumbs update.
- **Buttons**: primary = emerald fill + near-black text; hover lifts `translateY(-2px)` with emerald glow. Ghost = transparent + hairline border, hover brightens border. `.btn--sm` compact, `.btn--lg` large.
- **Hover**: rows go to `--hover`; cards lift subtly.
- **Live states**: "scanning" / "sending" pulse dots (emerald). Provide reduced-motion fallbacks.
- **Onboarding**: stepper advances; done steps show emerald check.
- **Responsive**: at ≤860px the sidebar collapses to a **floating bottom dock** (`rgba(16,18,24,0.86)` glass); content stacks single-column; topbar condenses. No horizontal overflow at ~390px.

## State Management
Prototype state is local React (`useState`): current `route`, `agentOpen`, `showOnb`. In production, back these with the app's real router (route per screen) and a global UI store for the agent drawer. Screen data here is static mock content — wire to real APIs (leads, channels, drafts, mailboxes, deals, metrics) per the host backend. No data fetching is implemented in the prototype.

## Assets
- `src/favicon.svg` — emerald rounded square, white "Q" (Bricolage).
- `landing/lp-assets/dashboard.png` — product screenshot for the landing hero (re-export from the rebuilt app when ready).
- `reference/01–08-*.png` — finished screenshots of each app screen.
- **Fonts** (Google Fonts; self-host in prod): Bricolage Grotesque 400–800, Geist 300–700, Geist Mono 400–500.
- Icons: small inline 1.5px-stroke SVG set in `components.jsx` (`Icon` component, ~30 glyphs). Map to the codebase's icon library (e.g. Lucide) if it has one, matching the 1.5px stroke weight.

## Files
**App**
- `src/index.html` — mounts React + Babel, loads `styles.css`, `components.jsx`, `app.jsx`, screens.
- `src/styles.css` — **all tokens + component styles** (authoritative).
- `src/components.jsx` — `Icon`, `Sidebar`/`NavItem`, `Topbar`, `SystemBar`, `Agent`, shared primitives (Stat, Sparkline, Bars, Avatar, Badge, ChannelChip, PageHead).
- `src/app.jsx` — shell, routes, ⌘K, screen switch.
- `src/screens/*.jsx` — the 8 screens + `onboarding.jsx`.

**Landing**
- `landing/Landing.html` + `landing/landing2.css` — marketing page (own token block, same Aurora palette). Sections: sticky nav, hero + product shot + proof stats + client logos, 4 feature rows, the loop, testimonials, pricing (**$39 Starter / $79 Pro / $149 Agency**, Pro highlighted), CTA band, footer. Reveal-on-scroll + count-up stats with a reveal-all failsafe.

> Brand: "Quelro" wordmark + emerald "Q" mark. Map all tokens onto the host design system instead of hardcoding hex where possible.

## Suggested prompt for Claude Code
> Read `design_handoff_quelro_app/README.md`, then the files in `src/` (especially `styles.css`, `app.jsx`, `components.jsx`, and `screens/*.jsx`) and `reference/*.png`. Reskin/rebuild the entire Quelro app in this codebase's stack using the Aurora dark theme and tokens in the README — all 8 screens, the sidebar, topbar, agent drawer, and onboarding — then apply the same system to the landing page in `landing/`. Match the spec faithfully and use our existing component patterns.
